# bemWithBootsrap

Репозиторий создан с цельюсомвестного обучения по видео курсу "Верстка по макету PSD на Bootstrap4 + BEM"

## Описание проекта
В этом Видео курсе - верстка по макету psd с применением Bootstrap4, методологии BEM (БЭМ), а так же работа в Photoshop и с репозиториями на GitHub. В этом видео мы подготовим все файлы для начала верстки и я расскажу о планах на этот видео курс.

## Ссылки
* __файлы с макетом PSD:__ https://yadi.sk/d/CtRanCZ06pEQBw  
* __Репозиторий GitHub:__ https://github.com/morphIsmail/bemWithBootsrap  


## Для поддержки развития проекта:
__Сбербанк VISA:__ 4276 5200 1409 4318  
__Yandex:__ 410011260821995 - https://yasobe.ru/na/itdoctor  
__QIWI:__ 4890 4943 0383 5581  
__WMR:__ R444308690108  
__WMZ:__ Z608507028676  


## Советую посмотреть:
__Основы БЭМ:__ https://www.youtube.com/watch?v=4DU--UjmYhk  
__Уроки по Bootstrap 4:__ https://www.youtube.com/playlist?list=PLuY6eeDuleIP8cwKmwmT2pAGFMnhI5qNO  
__Иконки для сайта:__ https://www.youtube.com/watch?v=E-DNlHs4BEo  
__Уроки по GitHub:__ https://www.youtube.com/playlist?list=PLuY6eeDuleIOMB2R_Kky05ZfiAx2_pbAH  
__Уроки по Photoshop:__ https://www.youtube.com/playlist?list=PLuY6eeDuleINP2w4V37k8f5Jxp5j8ndfU  


## Наши группы в Социальных сетях:  
__YouTube канал:__  https://www.youtube.com/channel/UC2Ev-rDSHBov0ZMChesLfrg  
* __Группа в ВК:__ https://vk.com/itdoctorstudio
* __Instagram:__ https://instagram.com/ismail_asanovich/
* __Telegram:__ https://t.me/itdoctorr
* __Мой Twitter:__ https://twitter.com/ITDoctor_morph
